<?php
/**
 * Created by Gorlum 14.02.2017 11:21
 */

/**
 * Back-compatibility functions
 */
