Extra files

phpBB3.zip - some phpBB3 stuff
sources - sources for used libraries
sql - sample SQL scripts
